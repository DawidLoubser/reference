package stc.voting;

import java.io.*;
import java.util.*;
import java.text.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.*;
import javax.servlet.http.*;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;

public class ElectionManagerServlet extends HttpServlet
{
   public void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException
   {
     try
     {
       BufferedReader reader = request.getReader();
       StringWriter writer = new StringWriter();

       writer.write(reader.readLine() + eol);
       while (reader.ready())
         writer.write(reader.readLine() + eol);
       writer.flush();

       StringReader in = new StringReader(writer.toString());

//       javax.servlet.ServletInputStream in = request.getInputStream();

       DocumentBuilder docBuilder
         = DocumentBuilderFactory.newInstance().newDocumentBuilder();
       Document doc = docBuilder.parse(new org.xml.sax.InputSource(in));

       Node env = doc.getDocumentElement();

       Node body = env.getLastChild();

       Node requestMsg = body.getFirstChild();

       NodeList args = requestMsg.getChildNodes();

       Node partyElement = args.item(0);

       Node numVotesElement = args.item(1);

       String party = partyElement.getFirstChild().getNodeValue();
       int numVotes = Integer.parseInt
                          (numVotesElement.getFirstChild().getNodeValue());

       createResponse(response, party, numVotes);
     }
     catch (Exception e)
     {
       try
       {
         createFaultResponse(response, e);
       }
       catch (Exception ex)  {throw new ServletException(ex);}
     }
   }

   public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException
   {
     response.getWriter().println("Web Service: Get not supported");
   }

  public void createResponse(HttpServletResponse response,
                             String partyName, int numVotes)
                   throws Exception
  {
    DocumentBuilder docBuilder
      = DocumentBuilderFactory.newInstance().newDocumentBuilder();
    Document doc = docBuilder.newDocument();

    Element envelope = doc.createElementNS(soapSchema, "soap:Envelope");
    Element body = doc.createElement("soap:Body");
    doc.appendChild(envelope);
    envelope.appendChild(body);

    Element responseMsg
      = doc.createElementNS(requestSchema, "msg:addVotesResponse");
    body.appendChild(responseMsg);

    responseMsg.appendChild(doc.createTextNode
      ("Added " + Integer.toString(numVotes) + " votes for " + partyName));

    response.getWriter().println(serializeResponse(doc));
  }

  public void createFaultResponse(HttpServletResponse response,
                                  Exception exception)
                   throws Exception
  {
    DocumentBuilder docBuilder
      = DocumentBuilderFactory.newInstance().newDocumentBuilder();
    Document doc = docBuilder.newDocument();

    Element envelope = doc.createElementNS(soapSchema, "soap:Envelope");
    Element body = doc.createElement("soap:Body");
    doc.appendChild(envelope);
    envelope.appendChild(body);

    Element faultMsg
      = doc.createElement("soap:Fault");
    body.appendChild(faultMsg);

    Element faultCode = doc.createElement("faultcode");
    faultCode.appendChild(doc.createTextNode("soap:Server"));
    faultMsg.appendChild(faultCode);

    Element faultString = doc.createElement("faultstring");
//    faultCode.appendChild(doc.createTextNode("Server Error"));
    faultCode.appendChild(doc.createTextNode(str));
    faultMsg.appendChild(faultString);

    Element detail = doc.createElement("detail");
    Element stackTrace = doc.createElement("stacktrace");
    stackTrace.appendChild
      (doc.createTextNode(exception.toString()));
    detail.appendChild(stackTrace);
    faultMsg.appendChild(detail);

    response.getWriter().println(serializeResponse(doc));
  }

  public StringBuffer serializeResponse(Document doc)
                  throws TransformerException,
                         TransformerConfigurationException
  {
    StringWriter resultString = new StringWriter();
    StreamResult resultStream = new StreamResult(resultString);

    DOMSource source = new DOMSource(doc);
    StreamResult result = new StreamResult(resultString);

    TransformerFactory transformerFactory
      = TransformerFactory.newInstance();

    Transformer transformer = transformerFactory.newTransformer();

    transformer.transform(source, resultStream);

    return resultString.getBuffer();
  }

  private String str;

  private static final String
    requestSchema = "http://www.SolmsTraining.co.za/voting";
  private static final String
    soapSchema = "http://schemas.xmlsoap.org/soap/envelope/";
  private static final String
    soapEncodingSchema = "http://www.w3.org/2001/soap-encoding";
  private static final String
    eol = System.getProperty("line.separator");
}
