import java.net.*;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;

public class PollingStationClient
{
  public static void main(String[] args)
  {
    new PollingStationClient().run();
  }

  public void run()
  {
    try
    {
      System.out.println("Constructing request");
      Document soapRequest
        = createAddVotesMessage("Don Quichote Party", 200);

      StringBuffer request = serializeXmlDoc(soapRequest);

      System.out.println("eol + The request:" + eol + request);

      insertHTTPHeader(request);

      System.out.println(eol + "Inserted HTTP header:" + eol + request);

      System.out.println(eol + "connecting to web service provider: "
                             + hostName + ", port: " + port);

      Socket socket = connect(hostName, port);

      System.out.println(eol + "Sending request");

      java.io.PrintStream socketOutput
        = new java.io.PrintStream(socket.getOutputStream());

      socketInput = socket.getInputStream();

      sendRequest(request, socketOutput);

      new Thread()
        {
	  public void run()
	  {
            PollingStationClient.this.extractResponse(socketInput);
	  }
	}.start();

      for (int i=0; i<300; ++i)
        System.out.println("busy doing other things.");
    }
    catch  (Exception e) {e.printStackTrace();}
  }

  public Document createAddVotesMessage(String partyName, int numVotes)
                   throws Exception
  {
    DocumentBuilder docBuilder
      = DocumentBuilderFactory.newInstance().newDocumentBuilder();
    Document doc = docBuilder.newDocument();

    Element envelope = doc.createElementNS(soapSchema, "soap:Envelope");
    Element body = doc.createElement("soap:Body");
    doc.appendChild(envelope);
    envelope.appendChild(body);

    Element request = doc.createElementNS(requestSchema, "msg:addVotes");
    body.appendChild(request);

    Element party = doc.createElement("msg:party");
    party.appendChild(doc.createTextNode(partyName));
    request.appendChild(party);

    Element noVotes = doc.createElement("msg:numVotes");
    noVotes.appendChild(doc.createTextNode(Integer.toString(numVotes)));
    request.appendChild(noVotes);

    return doc;
  }

  public StringBuffer serializeXmlDoc(Document doc)
                  throws TransformerException,
                         TransformerConfigurationException
  {
    java.io.StringWriter resultString = new java.io.StringWriter();
    StreamResult resultStream = new StreamResult(resultString);

    DOMSource source = new DOMSource(doc);
    StreamResult result = new StreamResult(resultString);

    TransformerFactory transformerFactory
      = TransformerFactory.newInstance();

    Transformer transformer = transformerFactory.newTransformer();

    transformer.transform(source, resultStream);

    return resultString.getBuffer();
  }

  public void insertHTTPHeader(StringBuffer request)
  {
    String httpHeader = "POST " + webService + " HTTP/1.1" + eol
                      + "Host: " +  hostName + eol
                      + "Content-Type: text/xml; charset=utf-8"
                      + eol + eol;

    request.insert(0, httpHeader);
  }

  public Socket connect(String hostName, int port)
                  throws java.io.IOException
  {
    InetAddress host = InetAddress.getByName(hostName);

    return new Socket(host,port);
  }

  public void sendRequest(StringBuffer request,
                          java.io.PrintStream socketOutput)
                throws java.io.IOException
  {
    socketOutput.println(request.toString());
  }

  public void extractResponse(java.io.InputStream socketInput)
  {
    try
    {
        java.io.BufferedReader in
          = new java.io.BufferedReader
             (new java.io.InputStreamReader(socketInput));

        StringBuffer responseStr = new StringBuffer();
        String line = in.readLine();
        while (line != null)
        {
          responseStr.append(line).append(eol);
          line = in.readLine();
        }

        System.out.println("HTTP response: " + responseStr);
        System.out.flush();

        // Remove up to XML declaration header
        responseStr.delete(0, responseStr.indexOf("<?xml"));

        DocumentBuilder docBuilder
          = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document doc = docBuilder.parse(new org.xml.sax.InputSource
                        (new java.io.StringReader(responseStr.toString())));

        System.out.println("SOAP Response:" + eol + serializeXmlDoc(doc));
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
  }

  private static final String
    requestSchema = "http://www.SolmsTraining.co.za/voting";
  private static final String
    soapSchema = "http://schemas.xmlsoap.org/soap/envelope/";
  private static final String
    soapEncodingSchema = "http://www.w3.org/2001/soap-encoding";

  private static final String hostName = "localhost";

  private static final int port = 8080;

  private static final String webService = "/voting/ElectionServer";

  private static final String eol = System.getProperty("line.separator");

  private       java.io.InputStream socketInput;
}
