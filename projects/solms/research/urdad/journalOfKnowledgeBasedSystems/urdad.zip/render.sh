latex urdad.tex
bibtex urdad
latex urdad.tex
dvipdf urdad.dvi
acroread urdad.pdf

